import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EKartRoutingGuard } from './app.routing-guard';
import { AuthorisationErrorComponent } from './shared/authorisation-error/authorisation-error.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CustomerModule } from './customer/customer.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { CardComponent } from './card/card.component';

//import {MatCardModule} from '@angular/material/card';
@NgModule({
  declarations: [
    AppComponent,
    AuthorisationErrorComponent,
    // CardComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AppRoutingModule,
    CustomerModule,
    BrowserAnimationsModule,
    CommonModule
    //MatCardModule
    
  ],
  providers: [EKartRoutingGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }

