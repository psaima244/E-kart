import { AbstractControl } from "@angular/forms";

//Validator class to validate the expiryDate
export class ExpiryDateValidator {
  /*method to check dateOfReading is a future date*/
  static checkExpiryDate(expiryDate: AbstractControl): { 'checkDate': true } | null {
    let value = "" + expiryDate.value;
    let date:Date=new Date();
    let dateofExpiry:Date=new Date(value);
    if(dateofExpiry <= date )
    { 
       return { 'checkDate': true };
    }
    return null;
  }
}
