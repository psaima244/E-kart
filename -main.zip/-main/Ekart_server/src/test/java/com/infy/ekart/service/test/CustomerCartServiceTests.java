package com.infy.ekart.service.test;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.infy.ekart.dto.CartProductDTO;
import com.infy.ekart.dto.CustomerCartDTO;
import com.infy.ekart.dto.ProductDTO;
import com.infy.ekart.entity.CartProduct;
import com.infy.ekart.entity.CustomerCart;
import com.infy.ekart.exception.EKartException;
import com.infy.ekart.repository.CustomerCartRepository;
import com.infy.ekart.service.CustomerCartService;
import com.infy.ekart.service.CustomerCartServiceImpl;

@SpringBootTest
class CustomerCartServiceTest {

	// Write testcases here

	@Mock
	private CustomerCartRepository customerCartRepository;

	@Mock
	private CustomerCartRepository cartProductRepository;

	@InjectMocks
	CustomerCartService customerCartService = new CustomerCartServiceImpl();
	@Test
	public void getAllProductsValid1() throws EKartException {

		// write your logic here
		CustomerCart cart = new CustomerCart();
		cart.setCartId(3000);
		Set<CartProduct> set = new HashSet<>();
		CartProduct product = new CartProduct();
		product.setCartProductId(6000);
		product.setProductId(1000);
		product.setQuantity(1);
		set.add(product);

		cart.setCartProducts(set);
		cart.setCustomerEmailId("tom@infosys.com");
		System.out.println(cart);
		Optional<CustomerCart> custCart = Optional.ofNullable(cart);
		Mockito.when(customerCartRepository.findByCustomerEmailId("tom@infosys.com")).thenReturn(custCart);
		//System.out.println(cart.getCustomerEmailId());
		CustomerCartDTO cartDTO = new CustomerCartDTO();
		Set<CartProductDTO> set1 = new HashSet<>();
		CartProductDTO product1 = new CartProductDTO();
		product1.setCartProductId(product.getCartProductId());

		ProductDTO prod = new ProductDTO();
		prod.setProductId(product.getCartProductId());
		prod.setBrand("Nicon");
		product1.setProduct(prod);
		set1.add(product1);
		cartDTO.setCartProducts(set1);
		cartDTO.setCustomerEmailId(cart.getCustomerEmailId());
		Integer exp = set1.stream().findFirst().get().getCartProductId();
		Integer actual = customerCartService.getProductsFromCart("tom@infosys.com").stream().findFirst().get().getCartProductId();

		Assertions.assertEquals(exp, actual);

	}
	@Test
	public void getAllProductsValid2() throws EKartException {

		// write your logic here
		CustomerCart cart = new CustomerCart();
		cart.setCartId(3000);
		Set<CartProduct> set = new HashSet<>();
		CartProduct product = new CartProduct();
		product.setCartProductId(6000);
		product.setProductId(1000);
		product.setQuantity(1);
		set.add(product);

		cart.setCartProducts(set);
		cart.setCustomerEmailId("tom@infosys.com");
		System.out.println(cart);
		Optional<CustomerCart> custCart = Optional.ofNullable(cart);
		Mockito.when(customerCartRepository.findByCustomerEmailId("tom@infosys.com")).thenReturn(custCart);

		Set<CartProductDTO> set2 = customerCartService.getProductsFromCart("tom@infosys.com");
		Assertions.assertFalse(set2.isEmpty());

	}
	@Test
	public void addProductToCartValidTest() throws EKartException {

		// write your logic here
		CustomerCart cart = new CustomerCart();
		cart.setCartId(3000);
		Set<CartProduct> set = new HashSet<>();
		CartProduct product = new CartProduct();
		product.setCartProductId(6000);
		product.setProductId(1000);
		product.setQuantity(1);
		set.add(product);

		cart.setCartProducts(set);
		cart.setCustomerEmailId("tom@infosys.com");
		Mockito.when(customerCartRepository.findByCustomerEmailId("tom@infosys.com")).thenReturn(Optional.of(cart));

		CustomerCartDTO cartDTO = new CustomerCartDTO();
		cartDTO.setCartId(cart.getCartId());
		Set<CartProductDTO> set1 = new HashSet<>();
		CartProductDTO product1 = new CartProductDTO();
		product1.setCartProductId(product.getCartProductId());
		ProductDTO prod = new ProductDTO();
		prod.setProductId(product.getProductId());
		product1.setQuantity(product.getQuantity());
		prod.setBrand("Nicon");
		product1.setProduct(prod);
		set1.add(product1);
		cartDTO.setCartProducts(set1);
		cartDTO.setCustomerEmailId(cart.getCustomerEmailId());

		Assertions.assertEquals(cart.getCartId(), customerCartService.addProductToCart(cartDTO) );



	}
	@Test
	public void getProductFromCartInvalidTest1() throws EKartException {


		CustomerCart cart = null;
		Mockito.when(customerCartRepository.findByCustomerEmailId("tom@infosys.com")).thenReturn(Optional.ofNullable(cart));
		EKartException exp = Assertions.assertThrows(EKartException.class, () -> customerCartService.getProductsFromCart("tom@infosys.com"));
		Assertions.assertEquals("CustomerCartService.NO_CART_FOUND", exp.getMessage());


	}
	@Test
	public void getProductFromCartInvalidTest2() throws EKartException {



		String email = "name@infosys.com";
		CustomerCart customerCart = new CustomerCart();
		customerCart.setCartId(2345);
		customerCart.setCustomerEmailId(email);
		Set<CartProduct> cartProductSet = new HashSet<>();
		customerCart.setCartProducts(cartProductSet);

		CartProduct product = new CartProduct();
		product.setCartProductId(6000);
		product.setProductId(1000);
		product.setQuantity(1);	



		Mockito.when(customerCartRepository.findByCustomerEmailId(Mockito.anyString()))
		.thenReturn(Optional.of(customerCart));
		EKartException exp = Assertions.assertThrows(EKartException.class,() -> customerCartService.getProductsFromCart(email) );
		Assertions.assertEquals("CustomerCartService.NO_PRODUCT_ADDED_TO_CART", exp.getMessage());


	}
	@Test
	public void deleteProductFromCartValid1() throws EKartException {

		// write your logic here

		CustomerCart cart = new CustomerCart();
		cart.setCartId(3000);
		Set<CartProduct> set = new HashSet<>();
		CartProduct product = new CartProduct();
		product.setCartProductId(6000);
		product.setCartProductId(1000);
		product.setQuantity(1);

		cart.setCartProducts(set);
		cart.setCustomerEmailId("tom@infosys.com");

		String email = "name@infosys.com";
		Integer productId = 135;
		Mockito.when(customerCartRepository.findByCustomerEmailId(Mockito.anyString())).thenReturn(Optional.empty());
		EKartException exp = Assertions.assertThrows(EKartException.class, ()-> customerCartService.deleteProductFromCart(email,  productId));
		Assertions.assertEquals("CustomerCartService.NO_CART_FOUND", exp.getMessage());

	}



	@Test
	public void deleteProductFromCartInValidTest1() {

		// write your logic here

		CustomerCart cart = new CustomerCart();
		cart.setCartId(1000);


		String email = "name@infosys.com";
		Integer productId = 2456;
		Mockito.when(customerCartRepository.findByCustomerEmailId(Mockito.anyString())).thenReturn(Optional.empty());
		EKartException exp = Assertions.assertThrows(EKartException.class,()-> customerCartService.deleteProductFromCart(email, productId));
		Assertions.assertEquals("CustomerCartService.NO_CART_FOUND", exp.getMessage());

	}
	@Test
	public void deleteProductFromCartInValidTest2() {

		// write your logic here
		String email = "name@infosys.com";
		Integer productId = 3456;

		CustomerCart customerCart = new CustomerCart();
		customerCart.setCustomerEmailId(email);
		Set<CartProduct> cartProductSet = new HashSet<>();
		customerCart.setCartProducts(cartProductSet);

		Mockito.when(customerCartRepository.findByCustomerEmailId(Mockito.anyString()))
		.thenReturn(Optional.of(customerCart));
		EKartException exp = Assertions.assertThrows(EKartException.class, ()-> customerCartService.deleteProductFromCart(email, productId));
		Assertions.assertEquals("CustomerCartService.NO_PRODUCT_ADDED_TO_CART", exp.getMessage());

	}

	@Test
	public void modifyQuantityOfProductInCartInValidTest1() {
		String email = "name@infosys.com";
		Integer productId = 135;
		Integer quantity = 1;
		Mockito.when(customerCartRepository.findByCustomerEmailId(Mockito.anyString())).thenReturn(Optional.empty());
		EKartException exp = Assertions.assertThrows(EKartException.class,
				() -> customerCartService.modifyQuantityOfProductInCart(email, productId, quantity));
		Assertions.assertEquals("CustomerCartService.NO_CART_FOUND", exp.getMessage());
	}

	@Test
	public void modifyQuantityOfProductInCartInvalidTest2() {
		String email = "name@infosys.com";
		Integer productId = 135;
		Integer quantity = 4;
		CustomerCart customerCart = new CustomerCart();
		customerCart.setCustomerEmailId(email);
		Set<CartProduct> cartProductSet = new HashSet<>();
		CartProduct cartProduct = new CartProduct();
		cartProduct.setProductId(132);
		cartProduct.setQuantity(87);
		cartProductSet.add(cartProduct);
		customerCart.setCartProducts(cartProductSet);
		Mockito.when(customerCartRepository.findByCustomerEmailId(Mockito.anyString()))
		.thenReturn(Optional.of(customerCart));
		EKartException exp = Assertions.assertThrows(EKartException.class,
				() -> customerCartService.modifyQuantityOfProductInCart(email, productId, quantity));
		Assertions.assertEquals("CustomerCartService.PRODUCT_ALREADY_NOT_AVAILABLE", exp.getMessage());

	}

	@Test
	public void modifyQuantityOfProductInCartInvalidTest3() {

		String email = "name@infosys.com";
		Integer productId = 135;
		Integer quantity = 4;
		Mockito.when(customerCartRepository.findByCustomerEmailId(Mockito.anyString())).thenReturn(Optional.empty());
		EKartException exp = Assertions.assertThrows(EKartException.class,
				() -> customerCartService.modifyQuantityOfProductInCart(email, productId, quantity));
		Assertions.assertEquals("CustomerCartService.NO_CART_FOUND", exp.getMessage());
	}

	@Test
	public void modifyQuantityOfProductInCartInValidTest4() {
		String email = "name@infosys.com";
		Integer productId = 135;
		Integer quantity = 1;
		Mockito.when(customerCartRepository.findByCustomerEmailId(Mockito.anyString())).thenReturn(Optional.empty());
		EKartException exp = Assertions.assertThrows(EKartException.class,
				() -> customerCartService.modifyQuantityOfProductInCart(email, productId, quantity));
		Assertions.assertEquals("CustomerCartService.NO_CART_FOUND", exp.getMessage());
	}

	@Test
	public void deleteAllProductsFromCartValidTest() {
		String email = "name@infosys.com";
		Mockito.when(customerCartRepository.findByCustomerEmailId(Mockito.anyString())).thenReturn(Optional.empty());
		EKartException exp = Assertions.assertThrows(EKartException.class,
				() -> customerCartService.deleteAllProductsFromCart(email));
		Assertions.assertEquals("CustomerCartService.NO_CART_FOUND", exp.getMessage());
	}

	@Test
	public void deleteAllProductFromCartInValidTest1() {
		String email = "name@infosys.com";
		CustomerCart customerCart = new CustomerCart();
		customerCart.setCustomerEmailId(email);
		Set<CartProduct> cartProductSet = new HashSet<>();
		customerCart.setCartProducts(cartProductSet);
		Mockito.when(customerCartRepository.findByCustomerEmailId(Mockito.anyString()))
		.thenReturn(Optional.of(customerCart));
		EKartException exp = Assertions.assertThrows(EKartException.class,
				() -> customerCartService.deleteAllProductsFromCart(email));
		Assertions.assertEquals("CustomerCartService.NO_PRODUCT_ADDED_TO_CART", exp.getMessage());

	}

	@Test
	public void modifyQuantityOfProductInCartInValidTest2() {
		String email = "name@infosys.com";
		Integer productId = 135;
		Integer quantity = 4;
		CustomerCart customerCart = new CustomerCart();
		customerCart.setCustomerEmailId(email);
		Set<CartProduct> cartProductSet = new HashSet<>();
		customerCart.setCartProducts(cartProductSet);
		Mockito.when(customerCartRepository.findByCustomerEmailId(Mockito.anyString()))
		.thenReturn(Optional.of(customerCart));
		EKartException exp = Assertions.assertThrows(EKartException.class,
				() -> customerCartService.modifyQuantityOfProductInCart(email, productId, quantity));
		Assertions.assertEquals("CustomerCartService.NO_PRODUCT_ADDED_TO_CART", exp.getMessage());

	}	

	@Test
	public void deleteAllProductsFromCartIValidTest3() {
		String email = "name@infosys.com";
		Mockito.when(customerCartRepository.findByCustomerEmailId(Mockito.anyString())).thenReturn(Optional.empty());
		EKartException exp = Assertions.assertThrows(EKartException.class,
				() -> customerCartService.deleteAllProductsFromCart(email));
		Assertions.assertEquals("CustomerCartService.NO_CART_FOUND", exp.getMessage());
	}

	@Test
	public void deleteAllProductsFromCartIValidTest4() {
		String email = "name@infosys.com";
		Mockito.when(customerCartRepository.findByCustomerEmailId(Mockito.anyString())).thenReturn(Optional.empty());
		EKartException exp = Assertions.assertThrows(EKartException.class,
				() -> customerCartService.deleteAllProductsFromCart(email));
		Assertions.assertEquals("CustomerCartService.NO_CART_FOUND", exp.getMessage());
	}

}
