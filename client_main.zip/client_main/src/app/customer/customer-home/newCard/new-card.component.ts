import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Card } from 'src/app/shared/model/card';
import { ExpiryDateValidator } from './new-card.validator';
import { NewCardService } from './new-card.service';

@Component({
  selector: 'app-new-card',
  templateUrl: './new-card.component.html',
  styleUrls: ['./new-card.component.css']
})
export class NewCardComponent implements OnInit {

  card!: Card;
  loggedInCustomer: any;
  addCardForm!: FormGroup;
  errorMessage!: string;
  successMessage!: any;
  constructor(private fb: FormBuilder, private cardService: NewCardService) { }

  ngOnInit(){
    this.card = new Card();
    this.createForm();
    this.loggedInCustomer = JSON.parse(sessionStorage.getItem("customer") || "{}");

  }

  createForm() {
    this.addCardForm= this.fb.group({
       cardType:[this.card.cardType,[Validators.required]],
       cardNumber:[this.card.cardNumber,[Validators.required,Validators.pattern("^[0-9]{16}$")]],
       nameOnCard:[this.card.nameOnCard,[Validators.required,Validators.pattern("^[A-Z][a-z]{2,}( [A-Z][a-z]*){0,2}$")]],
       cvv:[this.card.cvv,[Validators.required,Validators.pattern("^[0-9]{3}$")]],
      //  expiryDate:[this.card.expiryDate,[Validators.required]],
       customerEmailId:[this.card.customerEmailId,[Validators.required,Validators.email]],
       expiryDate:[this.card.expiryDate,[Validators.required,ExpiryDateValidator.checkExpiryDate]]
    });
  }
  addCard(){
      this.errorMessage = "";
        this.successMessage = "";
        this.card = this.addCardForm.value as Card;

        this.cardService.addNewCard(this.loggedInCustomer.emailId, this.card)
        .subscribe(
          success=>{
            this.successMessage=success;
          },
          error=>{
            console.log(error)
          }
        )

    }
}


