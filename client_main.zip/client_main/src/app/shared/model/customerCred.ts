export class CustomerCred{
    emailId!: string;
    password!: string;
}