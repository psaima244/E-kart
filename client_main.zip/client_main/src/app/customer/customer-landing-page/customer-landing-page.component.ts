import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-landing-page',
  templateUrl: './customer-landing-page.component.html'
})
export class CustomerLandingPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
