package com.infy.ekart.api;

public class SampleClass {
		//....
}
