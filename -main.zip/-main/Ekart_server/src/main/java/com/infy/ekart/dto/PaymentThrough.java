package com.infy.ekart.dto;

public enum PaymentThrough {

	DEBIT_CARD, CREDIT_CARD
}
