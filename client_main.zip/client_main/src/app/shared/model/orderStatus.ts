export enum OrderStatus{
    PLACED = "Order placed by customer",
    CONFIRMED = "Order has been confirmed by seller",
    CANCELLED = "Order was cancelled!!"
}