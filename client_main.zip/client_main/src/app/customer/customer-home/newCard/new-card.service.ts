import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, throwError } from 'rxjs';
import { Card } from 'src/app/shared/model/card';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class NewCardService {

  private headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  constructor(private http: HttpClient) { }

  addNewCard(customerEmailId: string, card:Card) {
    let url: string = environment.cardAPIUrl + "/customer/" + customerEmailId + '/cards';
    return this.http.post(url,card,{ responseType: "text" }).pipe(catchError(this.handleError));
    
    // return this.http.post(url, data, { responseType: "text" }).pipe(catchError(this.handleError));
}
  private handleError(err: HttpErrorResponse){
    console.log(err)
        let errMsg: string = '';
        if (err.error instanceof Error) {
            console.log("1"+err.error.message)
            errMsg = err.error. message;
            console.log(errMsg)
        }
        else if (typeof err.error === 'string') {
          errMsg = JSON.parse(err.error).errorMessage
      }
      else {

          if (err.status == 0) {

              errMsg = "A connection to back end can not be established.";
          } else {

              errMsg = err.error.message;

          }
      }
      return throwError(errMsg);
  }
}
