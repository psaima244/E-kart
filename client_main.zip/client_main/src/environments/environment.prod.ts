import { environment as common } from './environment';

export const environment = {

  ...common,

  production: true

};